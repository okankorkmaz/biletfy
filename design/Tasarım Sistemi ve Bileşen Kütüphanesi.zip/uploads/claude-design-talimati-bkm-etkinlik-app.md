# Claude Design Talimatı — BKM Mutfak "Etkinlik & Bilet Satış Takip" Mobil Uygulaması (Flutter)

> **Nasıl kullanılır:** Claude Design'da yeni bir proje aç, 6 ekranlık kolaj görselini ekle, bu metnin tamamını yapıştır. Çıktı uzun olacağı için en iyi sonuç iki aşamada gelir: önce **Bölüm 0–4** ile projenin tasarım sistemini oluşturt ve onayla; sonra **Bölüm 5–12** ile ekranları ürettir. Kolaj olmadan çalıştırma.

---

## 0. Rol ve amaç

Sen kıdemli bir mobil ürün tasarımcısısın. Ekteki kolaj (6 ekran, koyu tema, iPhone çerçevesi, Türkçe arayüz) referans alınarak **Flutter ile geliştirilecek** bir mobil uygulamanın eksiksiz UI tasarımını üreteceksin:

1. Tasarım sistemi (isimlendirilmiş token'lar)
2. Bileşen kütüphanesi (varyant ve durumlarıyla)
3. 6 ana ekran (kolajdaki mock veriyle birebir) + kolajda olmayan ekranlar ve durumlar
4. Navigasyon haritası ve Flutter handoff notu

**Sadakat kuralı:** Kolajdaki görsel dili birebir koru. "İyileştirme" adına stil değiştirme, yeniden yorumlama, yeni renk/şekil dili icat etme yok. Yalnızca (a) kolajda olmayan ekran ve durumları aynı dille tamamla, (b) Bölüm 10'daki tutarsızlıkları düzelt. Emin olmadığın her kararda kolaj kazanır.

---

## 1. Ürün özeti

- **Kim kullanıyor:** BKM Mutfak prodüksiyon/yönetim ekibi. Dahili operasyon aracı (B2B). Tüketiciye bilet satan bir uygulama değil.
- **Ne yapıyor:** Etkinliklerin (gösteri serilerinin) bilet satışını, doluluğunu, brüt gelirini, biletleme firmalarına göre dağılımını (Biletix, Bubilet, Biletinial, Diğer) ve günlük satış trendini takip eder; gösterileri takvimde gösterir.
- **Dil:** Türkçe. Tüm arayüz metinleri bu belgede verildiği gibi kullanılır; çeviri, kısaltma, İngilizceleştirme yok.
- **Ton:** Veri yoğun, sakin, operasyonel "gece modu kontrol paneli". Süs yok; hiyerarşi sayıyla kurulur (büyük sayı, küçük etiket).

---

## 2. Platform ve teknik kısıtlar (Flutter uyumu)

- Hedef: Flutter, iOS + Android tek kod tabanı. Tasarım çerçevesi **390×844** (iPhone 14/15), tüm ölçüler dp/pt (@1x).
- **8 pt grid** (4 pt yarım adım kabul). Ölçüleri 4'ün katı ver.
- **Font:** Inter (Google Fonts; iki platformda aynı). Sayılarda tabular figures (`tnum`) zorunlu. SF Pro veya sistem fontuna bağımlı kalma.
- **İkonlar:** tek set — Lucide (Flutter'da `lucide_icons`) ya da Material Symbols Rounded. Karıştırma. Boyutlar: nav 24, satır içi 20, chip/etiket içi 16.
- **Grafikler** `fl_chart` ile üretilebilecek türlerle sınırlı: donut (PieChart), çizgi (LineChart), dikey bar (BarChart), yatay ilerleme barları (LinearProgressIndicator). Egzotik grafik, 3D, animasyonlu süs yok.
- Bileşenler Material 3 tabanlı **özel dark ThemeData**'ya eşlenecek; bu yüzden renk/tipografi/spacing/radius token'ları isimli olsun (Bölüm 3).
- **Sadece koyu tema.** Açık tema tasarlama.
- Kolajdaki 9:41 iOS durum çubuğu yalnızca çerçeve; içerik safe area'lara saygılı (üst 47, alt 34).
- Dokunma hedefleri min 44×44.

---

## 3. Tasarım sistemi (token'lar)

Hex değerleri kolajdan tahminidir; kolajdan renk seçici ile doğrulayıp kesinleştir, sonra **her ekranda aynı token'ı** kullan. Token adlarını değiştirme (Flutter tarafı bu adlarla eşlenecek).

### 3.1 Renk

| Token | Hex (tahmini) | Kullanım |
|---|---|---|
| `bg` | #000000 | Ekran arka planı (OLED siyah) |
| `surface` | #151517 | Kartlar |
| `surfaceAlt` | #202024 | Kart içi hücreler, pasif chip, saat kutusu, dropdown chip |
| `border` | #2A2A2E | 1 pt kart kenarlığı, divider, grafik grid çizgileri, progress track |
| `textPrimary` | #FFFFFF | Değerler, başlıklar |
| `textSecondary` | #A1A1AA | Etiketler, ikincil metin, pasif nav |
| `textTertiary` | #6B6B72 | Komşu ay günleri, en düşük öncelikli metin |
| `primary` | #E5233D | BKM kırmızısı — yalnızca "aktif/seçili" anlamı: aktif chip, aktif nav sekmesi, seçili takvim günü, tab underline |
| `onPrimary` | #FFFFFF | Primary üzerindeki metin/ikon |
| `success` | #22C55E | Artış, satılan, "Devam Eden", günlük satış çizgisi |
| `warning` | #F59E0B | "Yaklaşan" |
| `danger` | #EF4444 | "Kalan", azalış |
| `info` | #3B82F6 | Birincil bar grafik, "Toplam Satılan" ikonu |
| `purple` | #8B5CF6 | "Ortalama Doluluk" ve "Ortalama Bilet Fiyatı" ikonları |
| `vendor.biletix` | #3B82F6 | Biletix (her yerde) |
| `vendor.bubilet` | #14B8A6 | Bubilet (her yerde) |
| `vendor.biletinial` | #F97316 | Biletinial (her yerde) |
| `vendor.diger` | #6B7280 | Diğer (her yerde) |

**Tint kuralı:** ikon konteynerleri ve durum pill arka planları = ilgili renk **%15 opak**; ikon/metin = rengin kendisi.

**KPI ikon renkleri:** Toplam Etkinlik → `primary` tint (pembe-kırmızı), Toplam Satılan → `info`, Toplam Gelir → `success`, Ortalama Doluluk → `purple`.

### 3.2 Tipografi (Inter, tabular figures)

| Token | Boyut / satır | Ağırlık | Kullanım |
|---|---|---|---|
| `displayNum` | 32 / 38 | Bold | "+2.846" hero sayısı |
| `numL` | 24 / 28 | Bold | KPI değerleri (28, 12.842, 12.842.600 ₺, %68,4) |
| `numM` | 20 / 24 | SemiBold | Kapasite/Satılan/Kalan, donut merkezi |
| `titleL` | 22 / 28 | Bold | Etkinlik detay başlığı |
| `titleM` | 17 / 22 | SemiBold | App bar başlığı, kart başlıkları, etkinlik adı, takvim ayı |
| `body` | 15 / 20 | Regular · SemiBold | Liste satırları, değerler |
| `label` | 13 / 18 | Medium | Chip metni, legend, trend rozeti |
| `caption` | 12 / 16 | Regular | Etiketler ("Toplam Satılan", "Doluluk"), durum metni, mekan |
| `micro` | 11 / 14 | Regular | Eksen etiketleri, "Gösteri", "satılan", "bilet", "(%43,9)" |
| `navLabel` | 10 / 12 | Medium | Alt navigasyon etiketleri |

### 3.3 Spacing ve şekil

- Ekran yatay padding **16**; kart iç padding **16**; kartlar arası **12**; bölüm başlığı ile kart arası **8**; bölümler arası **20**.
- Radius: kart **16**, kart içi hücre / chip kutusu **12**, ikon konteyneri **10**, afiş küçük resmi **10** (liste) / **12** (detay), pill ve progress **999**, bar grafik üst köşeleri **4**.
- Kenarlık: kartlarda 1 pt `border` (çok düşük kontrast). **Gölge yok**, blur yok — tamamen flat.
- Progress kalınlığı: liste kartı **4**, detay doluluk **6**, firma barları **4**.
- Dropdown chip yüksekliği 28; filter chip 32; app bar 56; bottom nav 56 + alt safe area.

### 3.4 Semantik renk kuralları (tüm ekranlarda geçerli)

1. **Durum:** Devam Eden → `success`; Yaklaşan → `warning`; Tamamlanan → `textTertiary`. Liste kartlarında düz renkli metin (caption), detay başlığında pill (tint arka plan).
2. **Sayısal ton:** satılan / artış / "+" ile başlayan değerler → `success`; kalan / azalış → `danger`; nötr toplamlar → `textPrimary`.
3. **Firma renkleri sabit ve global:** donut, legend, yatay barlar, Firmalar raporu — hepsinde aynı `vendor.*` token'ı.
4. **Etkinlik vurgu rengi:** her etkinliğin bir `accentColor` alanı vardır (afiş paletinden seçilir); liste kartındaki progress bar bu rengi kullanır; tanımsızsa `info`. (Kolajda mavi/mavi/turuncu/mor olarak görünen barların kuralı budur.)
5. `primary` kırmızı **veri rengi olarak kullanılmaz**; "Kalan" için ayrı `danger` token'ı var.
6. Yeni renk icat etme. Tabloda olmayan bir renge ihtiyaç duyarsan `surfaceAlt` ya da `textSecondary` ile çöz.

---

## 4. Bileşen kütüphanesi

Her bileşen için: anatomi, ölçüler, varyantlar, durumlar (default / pressed / disabled), önerilen Flutter widget karşılığı.

1. **TopBar** — yükseklik 56. (a) Kök sekmeler: sol hamburger 24, ortada `titleM` başlık, sağda tek aksiyon ikonu (arama / takvim / paylaş / zil). (b) Push ekranlar: sol geri oku. Ana Sayfa'da başlık yerine sol üstte **logo placeholder** (64×32 kutu, "LOGO" yazılı; gerçek SVG sonradan eklenecek). → `AppBar`
2. **BottomNav** — 5 sekme: Ana Sayfa (home), Etkinlikler (list / ticket), Raporlar (bar-chart), Takvim (calendar), Ayarlar (settings). İkon 24 + `navLabel`; aktif `primary`, pasif `textSecondary`. Üst kenarlık 1 pt `border`. **Push ekranlarda gizlenir.** → `NavigationBar` / özel `BottomNavigationBar`
3. **FilterChipRow** — yatay kaydırılabilir pill'ler, aralık 8. Aktif: `primary` bg + `onPrimary`; pasif: `surfaceAlt` bg + `textSecondary`. Yükseklik 32, iç yatay padding 14, `label`. → `ChoiceChip`
4. **DropdownChip** — "Bugün ▾", "7 Gün ▾", "Mayıs 2026 ▾", "01 Mayıs - 15 Mayıs 2026 ▾": `surfaceAlt`, radius 999, caption Medium + chevron-down 14. Kart başlığının sağına hizalı. Basınca bottom sheet açar. → `PopupMenuButton` / `showModalBottomSheet`
5. **KpiCard** — sol üstte 32×32 ikon konteyneri (radius 10, tint bg, 18 pt ikon); sağında `caption` etiket; altta `numL` değer. Renk varyantları: primary / info / success / purple. 2×2 grid, gap 12, yükseklik ~88. → `Card` + `Column`
6. **SectionCard** — `surface` bg, radius 16, padding 16, 1 pt `border`; opsiyonel başlık satırı (`titleM` sol + `DropdownChip` sağ). → `Card`
7. **DonutChart** — çap 120, kalınlık 24, segmentler arası 2 pt boşluk, `vendor.*` renkleri; merkezde `numM` değer + `micro` "Toplam Bilet". Sağda legend: 8 pt renkli nokta + isim (`label`) + değer (`label` SemiBold) + "(%…)" `micro` `textSecondary`. → `fl_chart PieChart`
8. **MiniStatCell** — `surfaceAlt`, radius 12, padding 10; üstte `micro` etiket (Dün'de 12 pt saat ikonu), altta 17 SemiBold değer `success`. 4'lü eşit yatay grid, gap 8. → `Container` grid
9. **EventListCard** — `surface`, radius 16, padding 12. Sol 76×76 afiş placeholder (radius 10). Sağ: `titleM` başlık (max 2 satır), altında durum metni `caption`. Sağ üst köşe: gösteri sayısı 17 SemiBold + altında `micro` "Gösteri". Alt satır iki kolon: `caption` "Toplam Satılan" + `body` SemiBold değer; `caption` "Doluluk" + "%71,2" `body` SemiBold. En altta tam genişlik 4 pt progress (`accentColor`, track `border`). Tüm kart tıklanabilir → Etkinlik Detayı. Opsiyonel doluluk değişim rozeti ("↑3"): ya tüm kartlarda ya hiç. → `InkWell` + `Card`
10. **StatusChip / StatusText** — Bölüm 3.4 semantiği. Pill: yükseklik 24, padding 10, `label`, tint bg.
11. **EventHeader** (detay) — 96×96 afiş placeholder + `titleL` başlık + pin ikonu/mekan (`body` `textSecondary`) + takvim ikonu/tarih-saat + `StatusChip`.
12. **StatTrio** — `SectionCard` içinde 3 eşit kolon: `caption` etiket + `numM` değer. Renkler sırasıyla `textPrimary` / `success` / `danger`.
13. **LabeledProgress** — sol `caption` etiket, sağ `label` değer, altında 6 pt bar. → `LinearProgressIndicator`
14. **VendorBarList** — satır: isim (`body`), sağda değer (`body` SemiBold) + yüzde (`caption`, sağa dayalı, 48 pt sabit genişlik); altında 4 pt bar (`vendor.*`). Satır arası 12.
15. **SegmentedTabs (underline)** — 3 sekme, eşit genişlik; aktif: `primary` metin + 2 pt `primary` underline; pasif `textSecondary`. Detay ekranında **altta** (kolaja sadık); Flutter'da `TabBar` + `TabBarView`. Alternatif olarak header altına sabitlenebilir — kolaj konumunu varsayılan yap, alternatifi tek ekran olarak göster.
16. **HeroNumber** — üstte `caption` "Son 7 Gün Toplam"; `displayNum` `success` değer + yanında `micro` "bilet"; sağda trend rozeti: trending-up ikon 14 + "%18,6" `label` SemiBold `success`, altında `micro` "(Önceki 7 güne göre)".
17. **LineChart** — 7 nokta; çizgi 2 pt `success`; noktalar 6 pt (dolu `success`, 2 pt `bg` kenar); her noktanın üstünde `micro` değer; y ekseni 0–1.000 adım 200 (etiketler "1.000" formatında); x etiketleri iki satır: gün numarası üstte, "Mayıs" altta; yatay kesikli grid `border`; opsiyonel %8 opak `success` alan dolgusu. → `fl_chart LineChart`
18. **BarChart** — 4 kova (1-7, 8-15, 16-23, 24-31 Mayıs); bar genişliği 32, üst radius 4, `info`; üstte `micro` değer; veri olmayan kovada değer yerine "–"; y ekseni 0 / 2K / 4K / 6K / 8K. → `fl_chart BarChart`
19. **DataRowList** — "15 Mayıs 2026 … 529": sol `body`, sağ `body` SemiBold `success`; 1 pt `border` divider; satır yüksekliği 44.
20. **CalendarMonth** — başlık satırı: chevron-left, "Mayıs 2026" `titleM`, chevron-right. Haftanın günleri Pzt Sal Çar Per Cum Cmt Paz (`caption` `textSecondary`). 7 kolon, hücre 40×40, sayılar `body`. Komşu ay günleri `textTertiary`. Seçili gün: `primary` dolu daire + `onPrimary`. Bugün (seçili değilse): 1.5 pt `primary` halka. Etkinlikli gün: hücre altında 4 pt `textSecondary` nokta (kolajda yok, ekle). → özel `GridView` veya `table_calendar`
21. **DayEventRow** — sol saat kutusu 52×32 (`surfaceAlt`, radius 8, `label` SemiBold); orta: `body` SemiBold başlık, `caption` mekan, `caption` renkli durum; sağ: `body` SemiBold satılan + altında `micro` "satılan". Satır arası 8, tıklanabilir → Etkinlik Detayı.
22. **PosterPlaceholder** — nötr koyu gradient (`surfaceAlt` → `border`) + ortada etkinlik baş harfleri (`titleM` `textSecondary`). Gerçek afiş/fotoğraf yok.
23. **EmptyState / Skeleton / ErrorState / OfflineBanner** — Bölüm 6.

---

## 5. Ana ekranlar (kolajla birebir, mock veriyle)

Tüm ekranlar 390×844, `bg` siyah, dikey kaydırılabilir içerik. Aşağıdaki sıra, üstten alta yerleşim sırasıdır.

### 5.1 `01_AnaSayfa`

1. TopBar: sol logo placeholder, sağ zil ikonu.
2. Satır: "Genel Bakış" (`titleM`) — sağda DropdownChip **"Bugün ▾"** (seçenekler: Bugün, Bu Hafta, Bu Ay, Tümü).
3. KpiCard 2×2:
   - **Toplam Etkinlik** — `28` — primary tint, ticket ikonu
   - **Toplam Satılan** — `12.842` — info, ticket-check ikonu
   - **Toplam Gelir** — `12.842.600 ₺` — success, ₺ / banknote ikonu
   - **Ortalama Doluluk** — `%68,4` — purple, trending-up ikonu
4. SectionCard **"Satış Dağılımı (Tüm Etkinlikler)"** → DonutChart; merkez `12.842` / "Toplam Bilet"; legend:
   - Biletix — 5.642 (%43,9)
   - Bubilet — 4.128 (%32,1)
   - Biletinial — 2.034 (%15,8)
   - Diğer — 1.038 (%8,1)
5. SectionCard **"Günlük Satış Özeti"** + DropdownChip **"7 Gün ▾"** → MiniStatCell ×4: **Dün** `+444` · **Bugün** `+529` · **Son 7 Gün** `+2.846` · **Günlük Ort.** `+407` (Bölüm 10 düzeltmesi; kolajda +368 / +512). Kart tıklanınca → 04_GunlukSatis.
6. BottomNav — Ana Sayfa aktif.

### 5.2 `02_Etkinlikler`

1. TopBar kök: hamburger, "Etkinlikler", arama ikonu.
2. FilterChipRow: **Tümü** (aktif) · Devam Eden · Yaklaşan · Tamamlanan.
3. EventListCard listesi, sıralama **Toplam Satılan azalan**:

| Başlık | Durum | Gösteri | Toplam Satılan | Doluluk | accentColor |
|---|---|---|---|---|---|
| Çok Güzel Hareketler 2 | Devam Eden | 8 | 5.312 | %71,2 | info (mavi) |
| Doğu Demirkol | Devam Eden | 4 | 2.350 | %62,7 | info (mavi) |
| Meksika Açmazı | Yaklaşan | 2 | 1.124 | %55,8 | vendor.biletinial (turuncu) |
| Okan Çabalar | Devam Eden | 3 | 986 | %48,3 | purple (mor) |
| Tahsin Hasoğlu | Yaklaşan | 2 | 742 | %41,0 | warning (sarı) — kolajda kesik, bu değerleri kullan |
| Gece Yarısı Kabare | Tamamlanan | 6 | 3.410 | %89,5 | textTertiary — "Tamamlanan" filtresi için eklendi |
| Doğaçlama Gecesi | Tamamlanan | 1 | 640 | %94,2 | textTertiary — eklendi |

4. Kart dokununca → 03. Liste sonunda `caption` "28 etkinlik".
5. BottomNav — Etkinlikler aktif.

### 5.3 `03_EtkinlikDetayi_GenelBakis`

Detay ekranı **seçili gösteriye** (show) aittir; varsayılan olarak en yakın tarihli gösteri açılır. Tarih satırı aynı zamanda gösteri seçicidir (chevron-down ile). Serinin tüm gösterileri "Detaylar" sekmesinde listelenir.

1. TopBar push: geri, "Etkinlik Detayı", paylaş ikonu.
2. EventHeader: afiş placeholder; **Çok Güzel Hareketler 2**; pin · "İstanbul - Zorlu PSM"; takvim · **"15 Mayıs 2026 - 20:30 ▾"** (Bölüm 10 düzeltmesi; kolajda "15 Eylül"); StatusChip **Devam Eden**.
3. StatTrio: **Kapasite** `850` · **Satılan** `643` (success) · **Kalan** `207` (danger).
4. LabeledProgress: "Doluluk Oranı" — `%75,6` — 6 pt `success` bar, %75,6 dolu.
5. KpiCard ×2 yan yana (gap 12): **Brüt Satış** `643.000 ₺` (info, ₺ ikonu) · **Ortalama Bilet Fiyatı** `1.000 ₺` (purple, ticket/tag ikonu).
6. SectionCard **"Biletleme Firmalarına Göre Dağılım"** → VendorBarList:
   - Biletix — 310 — %48,2
   - Bubilet — 220 — %34,2
   - Biletinial — 83 — %12,9
   - Diğer — 30 — %4,7
7. Altta SegmentedTabs: **Genel Bakış** (aktif) · Günlük Satış · Detaylar. BottomNav yok.

### 5.4 `04_GunlukSatis`

1. TopBar push: geri, "Günlük Satış", takvim ikonu (özel tarih aralığı seçici).
2. FilterChipRow: **7 Gün** (aktif) · 30 Gün · 90 Gün · Tümü.
3. HeroNumber: "Son 7 Gün Toplam" / `+2.846` bilet / trend "↗ %18,6" + "(Önceki 7 güne göre)".
4. SectionCard → LineChart (x: 9…15 Mayıs; y: 256, 312, 428, 365, 512, 444, 529).
5. SectionCard **"Günlük Satış Rakamları"** → DataRowList, tarih azalan:
   - 15 Mayıs 2026 — 529
   - 14 Mayıs 2026 — 444
   - 13 Mayıs 2026 — 512
   - 12 Mayıs 2026 — 365
   - 11 Mayıs 2026 — 428
   - 10 Mayıs 2026 — 312
   - 9 Mayıs 2026 — 256
6. BottomNav yok (push ekran). Etkinlik Detayı'ndan açıldığında aynı ekran, başlık "Günlük Satış" altında `caption` etkinlik adı ile.

### 5.5 `05_Raporlar_Satis`

1. TopBar kök: hamburger, "Raporlar", sağda dışa aktar (share) ikonu — kolajda boş, ekle.
2. FilterChipRow: **Satış** (aktif) · Gelir · Doluluk · Firmalar.
3. SectionCard **"Satış Dağılımı (Tüm Etkinlikler)"** + DropdownChip **"01 Mayıs - 15 Mayıs 2026 ▾"** → DonutChart (5.1 ile aynı veri ve legend).
4. SectionCard **"Aylık Satış Trendi"** + DropdownChip **"Mayıs 2026 ▾"** → BarChart: 1-7 Mayıs `5.124` · 8-15 Mayıs `7.718` · 16-23 Mayıs `–` · 24-31 Mayıs `–`.
5. BottomNav — Raporlar aktif.

### 5.6 `06_Takvim`

1. TopBar kök: hamburger, "Takvim", sağda "bugüne git" takvim ikonu.
2. CalendarMonth: **Mayıs 2026**, Pazartesi başlangıçlı grid (1 Mayıs 2026 Cuma'dır; ilk satır 28 29 30 soluk, 1 2 3 4; son satır 26 27 28 29 30 31 ve 1 soluk). **15** seçili (primary daire). Etkinlikli günlerde nokta.
3. Gün başlığı: **"15 Mayıs 2026 Cuma"** (`titleM`).
4. DayEventRow ×5, sıralama **satılan azalan** (kolajla aynı):
   - 20:30 — Çok Güzel Hareketler 2 — Zorlu PSM - İstanbul — Devam Eden — 643 satılan
   - 20:00 — Doğu Demirkol — Maximum Uniq Hall - İstanbul — Devam Eden — 412 satılan
   - 20:30 — Okan Çabalar — Bostancı Gösteri Merkezi - İstanbul — Devam Eden — 278 satılan
   - 21:00 — Tahsin Hasoğlu — Caddebostan Kültür Merkezi - İstanbul — Yaklaşan — 156 satılan
   - 20:30 — Meksika Açmazı — Trump Sahne - İstanbul — Yaklaşan — 98 satılan
5. BottomNav — Takvim aktif.

---

## 6. Kolajda olmayan ekranlar ve durumlar (aynı dille tamamla)

- `07_Ayarlar`: hesap/profil, bildirim tercihleri (günlük satış özeti saati, doluluk eşiği uyarısı), veri kaynakları / firma entegrasyonları (Biletix, Bubilet, Biletinial bağlantı durumu), para birimi ve tarih formatı, sürüm, çıkış. Liste satırları `surface` kart gruplarında, `textSecondary` alt açıklamalar.
- `08_Bildirimler` (zil): tarih gruplu liste ("Bugün", "Dün"); satır: ikon konteyneri + başlık + `caption` zaman; okunmamış satırda sol 6 pt `primary` nokta.
- `09_Arama` (Etkinlikler > arama): üstte arama alanı (`surfaceAlt`, radius 12), altında EventListCard sonuçları; boş sonuç durumu.
- `10_Drawer` (hamburger): kullanıcı adı/rol, 5 kök sekmeye kısayol, Ayarlar, sürüm etiketi.
- `11_EtkinlikDetayi_GunlukSatis`: 04 ekranının bu etkinliğe filtreli hali, altta SegmentedTabs (Günlük Satış aktif).
- `12_EtkinlikDetayi_Detaylar`: serinin gösteri listesi (tarih-saat / mekan / kapasite / satılan / doluluk mini progress), bilet fiyat kademeleri, seçili gösteriyi değiştirme; altta SegmentedTabs (Detaylar aktif).
- `13_Raporlar_Gelir`: ₺ bazlı donut (firma payı gelir olarak) + haftalık brüt gelir BarChart.
- `14_Raporlar_Doluluk`: etkinlik bazlı yatay bar sıralaması (VendorBarList biçimi, `accentColor`), ortalama doluluk çizgisi.
- `15_Raporlar_Firmalar`: firma karşılaştırma tablosu (satılan, pay, ortalama fiyat) + 4 renkli çoklu LineChart.
- `16_Durumlar`: boş durum (ikon + `body` metin + ikincil buton), yükleniyor iskeletleri (kart şekilli shimmer, `surfaceAlt` üzerinde), hata / yeniden dene, çevrimdışı banner (`warning` tint, üstte), pull-to-refresh göstergesi. "Son güncelleme 15 May 20:31" `caption`'ı Ana Sayfa "Genel Bakış" satırının altına opsiyonel.
- Günlük Satış 30 Gün / 90 Gün / Tümü varyantları: nokta değer etiketleri gizlenir, x ekseni seyrekleşir (haftalık/aylık), hero etiketi "Son 30 Gün Toplam" vb.

---

## 7. Navigasyon haritası

- **BottomNav (5 kök):** Ana Sayfa · Etkinlikler · Raporlar · Takvim · Ayarlar. Kök ekranlarda hamburger → Drawer.
- **Ana Sayfa →** "Toplam Etkinlik" kartı → Etkinlikler; "Satış Dağılımı" kartı → Raporlar/Satış; "Günlük Satış Özeti" kartı → Günlük Satış; zil → Bildirimler.
- **Etkinlikler →** arama → Arama; kart → Etkinlik Detayı (3 sekme: Genel Bakış / Günlük Satış / Detaylar).
- **Takvim →** gün seç → o günün gösterileri; satır → Etkinlik Detayı (ilgili gösteri seçili).
- **Raporlar →** 4 sekme; dışa aktar → sistem paylaşım sayfası (PNG/PDF).
- **Etkinlik Detayı →** paylaş → sistem paylaşım sayfası.
- Push ekranlarda BottomNav gizli, geri oku var; iOS'ta kenardan kaydırarak geri desteklenir.

---

## 8. Veri ve format kuralları (tr_TR)

- Binlik ayırıcı nokta, ondalık virgül: `12.842`, `%68,4`
- Yüzde işareti **önde**: `%71,2`
- Para: değer + boşluk + ₺: `12.842.600 ₺`, `1.000 ₺`
- Artış değerleri "+" ile: `+2.846`; azalış "−" ile ve `danger`
- Tarih: `15 Mayıs 2026`; günlü: `15 Mayıs 2026 Cuma`; saat 24s: `20:30`; tarih-saat: `15 Mayıs 2026 - 20:30`
- Hafta Pazartesi başlar; gün kısaltmaları Pzt Sal Çar Per Cum Cmt Paz
- Aralıklar: `01 Mayıs - 15 Mayıs 2026`; hafta kovaları `1-7 Mayıs`
- Eksen kısaltmaları: `2K / 4K / 6K`
- Tüm sayılar tabular; sağa dayalı değer kolonları aynı hizada.

---

## 9. Veri modeli (ekranlar arası tutarlılık için)

- **Event:** id, title, poster, status (devamEden | yaklasan | tamamlanan), showCount, totalSold, occupancyPct, accentColor
- **Show:** eventId, dateTime, venue, city, capacity, sold, remaining, grossRevenue, avgTicketPrice, vendorBreakdown[{ vendor, sold, pct }]
- **DailySales:** date, sold (global ya da eventId filtreli)
- **Vendor:** biletix | bubilet | biletinial | diger (sabit renkler)
- **Overview:** period, totalEvents, totalSold, totalRevenue, avgOccupancy
- Durum tanımı: **Devam Eden** = seri sürüyor (satış açık, gösteriler devam ediyor); **Yaklaşan** = ilk gösteri henüz gerçekleşmedi; **Tamamlanan** = tüm gösteriler bitti.

---

## 10. Tutarsızlık düzeltmeleri (kolajdaki mock hataları — tasarımda düzelt)

1. Etkinlik Detayı tarihi **"15 Eylül 2026"** → **"15 Mayıs 2026 - 20:30"**. Takvim, günlük satış ve aylık trend verilerinin tamamı 15 Mayıs 2026 itibarıyladır (1-7 + 8-15 Mayıs = 5.124 + 7.718 = 12.842 = toplam).
2. Ana Sayfa "Günlük Satış Özeti": kolajda **Dün +368 / Bugün +512**; Günlük Satış ekranında 14 Mayıs = 444, 15 Mayıs = 529. Tek kaynak: **Dün +444, Bugün +529**, Son 7 Gün +2.846, Günlük Ort. +407.
3. Bubilet rengi donut legend'da teal, detay barında yeşil → tek token `vendor.bubilet`, her yerde aynı.
4. Liste kartlarındaki progress renkleri rastgele görünüyor → `accentColor` kuralı (3.4 / madde 4).
5. Toplam Gelir ile Ortalama Bilet Fiyatı tutarlı: 12.842 × 1.000 ₺ = 12.842.600 ₺ — koru. Firma dağılımı 310 + 220 + 83 + 30 = 643 — koru.
6. Etkinlikler listesinde Tahsin Hasoğlu satırı kesik → Bölüm 5.2 tablosundaki değerleri kullan.

---

## 11. Yapma listesi

- Gerçek afiş, fotoğraf veya logo **kullanma** → PosterPlaceholder ve logo placeholder (gerçek varlıklar Flutter tarafında eklenecek).
- Yeni renk, gradient, gölge, blur, glassmorphism, 3D ekleme.
- Açık tema tasarlama.
- iOS'a özel bileşen (Cupertino picker, segmented control) veya Android'e özel FAB ekleme.
- Metinleri İngilizceleştirme, kısaltma, yeniden yazma.
- fl_chart ile üretilemeyecek grafik türü önerme.
- Kolajdaki bilgi hiyerarşisini değiştirme (büyük sayı üstte, küçük etiket altta; kart başlığı sol, dropdown sağ).

---

## 12. Teslimat formatı ve sırası

1. **Tasarım sistemi sayfası:** renk / tipografi / spacing / radius token tabloları, ikon seti, semantik kurallar. Ek olarak token'ları aşağıdaki şemayla **JSON** olarak ver (Flutter ThemeData'ya taşınacak):
   ```json
   {
     "color": { "bg": "#000000", "surface": "#151517", "primary": "#E5233D", "vendor": { "biletix": "#3B82F6" } },
     "radius": { "card": 16, "cell": 12, "icon": 10, "pill": 999 },
     "space": { "screenX": 16, "cardPadding": 16, "cardGap": 12, "sectionGap": 20 },
     "type": { "numL": { "size": 24, "lineHeight": 28, "weight": 700, "tabular": true } }
   }
   ```
2. **Bileşen kütüphanesi sayfası:** Bölüm 4'teki 23 bileşen, tüm varyant ve durumlarıyla, ölçü notlarıyla.
3. **6 ana ekran** (390×844) — frame adları: `01_AnaSayfa`, `02_Etkinlikler`, `03_EtkinlikDetayi_GenelBakis`, `04_GunlukSatis`, `05_Raporlar_Satis`, `06_Takvim`.
4. **Ek ekranlar ve durumlar** (Bölüm 6) — `07`…`16` adlandırmasıyla.
5. **Akış diyagramı** (Bölüm 7).
6. **Flutter handoff notu:** her bileşen → widget karşılığı; önerilen paketler (`google_fonts`, `fl_chart`, `go_router`, `intl` tr_TR, `lucide_icons` veya Material Symbols, `shimmer`, opsiyonel `table_calendar`); `ColorScheme.dark` + `TextTheme` eşleme özeti; spacing/radius sabitleri tek Dart dosyası önerisi (`AppTokens`).

**Öncelik sırası:** tutarlılık > kapsam > süs. Tereddütte kolaj kazanır.
